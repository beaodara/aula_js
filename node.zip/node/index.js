const express = require ('express')
const app = express()
const handlebars = require('express-handlebars')
const Sequelize = require('sequelize')

app.get('/cadastro',function(req, res){
    res.render('formularios')
})

app.engine('handlebars',handlebars.engine({defaultLayout:'main'}))
app.set('view engine', 'handlebars')

const sequelize = new Sequelize('teste2', 'root', '000000',{
    host:"localhost",
    dialect:"mysql"
})

app.listen(8081, function(){
    console.log("Servidor online.")
})