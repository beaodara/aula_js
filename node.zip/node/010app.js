var http = require('http')

http.createServer(function(req,res){

    res.end("tested")

}).listen(8081)

console.log("the server is running")