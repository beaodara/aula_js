const express = require("express")
const app = express()

app.get("/",function(req,res){
    res.send("hello, world")
})

app.get("/test", function (req,res){
    res.send("all fine, dude!")
})

app.get("/link", function (req,res){
    res.send("all fine, dude!")
})


app.get("/data/:dia/:mes/:ano", function(req, res){
    res.send(
        "<h1>Dia: " + req.params.dia + "</h1>" +
        "<h1>Mês: " + req.params.mes + "</h1>" +
        "<h1>Ano: " + req.params.ano + "</h1>" 
        )

})

app.listen(8081,function(){
    console.log("the server is running")
})