const { text } = require('express')
const Sequelize = require('sequelize')
const sequelize = new Sequelize('teste2', 'root', '000000',{
    host: "localhost",
    dialect: 'mysql'
})

sequelize.authenticate().then(function(){
    console.log("Conectado com sucesso")
}).catch(function(erro){
    console.log("Falha na conexão: " + erro)
})

const Postagem = sequelize.define('postagens', {
    titulo:{
        type: Sequelize.STRING
    },
    texto: {
        type:Sequelize.TEXT
    }
})

//Postagens.sync({force:true})

const Cadastro = sequelize.define('cadastro', {
    nome:{
        type: Sequelize.STRING
    },
    sobrenome:{
        type: Sequelize.STRING
    },
    idade:{
        type: Sequelize.INTEGER
    },
    email:{
        type: Sequelize.STRING
    },
    telefone:{
        type: Sequelize.INTEGER
    }

})

//Cadastro.sync({force:true})

Postagem.create({
    titulo: "Minha primeira publicação",
    texto: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
})

Cadastro.create({
    nome: "Beatriz",
    sobrenome: "Portela",
    idade: 23,
    email: "beatriz.portela@email.com",
    telefone: 123498765
})

Cadastro.create({
    nome: "Bruno",
    sobrenome: "Castro",
    idade: 25,
    email: "bruno.castro@email.com",
    telefone: 12345294
})

Cadastro.create({
    nome: "Alexandre",
    sobrenome: "Barros",
    idade: 31,
    email: "alexandre.barros@email.com",
    telefone: 12343641
})

Cadastro.create({
    nome: "Aline",
    sobrenome: "Silva",
    idade: 28,
    email: "aline.silva@email.com",
    telefone: 123459514
})

Cadastro.create({
    nome: "Natalia",
    sobrenome: "Campos",
    idade: 19,
    email: "natalia.campos@email.com",
    telefone: 12344568
})